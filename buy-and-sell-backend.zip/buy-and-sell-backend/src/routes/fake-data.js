

export const fakeListings = [{
    id:'123',
    name: "Old Bloat",
    description: "A very old boat",
    price:700,
},
{
    id:'345',
    name: 'Computer',
    description: 'From 1990',
    price:300,

},
{
    id:'456',
    name: 'BasketBall',
    description: 'Good condition',
    price:500,
},
{
    id:'567',
    name: 'New Bloat',
    description: 'A very new boat',
    price:1000,
}
]