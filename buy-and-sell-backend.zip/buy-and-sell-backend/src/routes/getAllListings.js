//import { fakeListings } from "./fake-data";
import {db} from '../database';

export const getAllListingsRoute = {

    method : 'GET',
    path : '/api/listings',
    handler : async (req,h) => {   /* async keyword is used because we are using 'await' is used inside*/
       // return fakeListings; /* we are going to use datas from database instead of from fakeLisings*/
       try{
           
        const {results} = await db.query(
            'SELECT * FROM listings',    
            );
                return results;
            /* to retreive records from listings table from mysql db*/
           
        
       }
       catch (error) {
           console.log('db:'+ db.query);            
        error.message 
       }
       
    }
}