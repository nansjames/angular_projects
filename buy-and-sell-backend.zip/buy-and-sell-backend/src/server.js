import Hapi from '@hapi/hapi';
import  routes from './routes';
import {db} from './database';

let server; /* This is used In order to refer the server call back await 'server.stop({timeout : 10000 })'
                            in 'process.on('SIGINT'*/

const  start = async () => {
   // const server = Hapi.Server({  As the server can be killed by ctrl+c we cannot tell as const server
      server = Hapi.Server({
        port : 8000,
        host : 'localhost',

    });

   /* server.route({
        method : 'GET',
      // method : 'POST',
        path : '/hello',
        handler : (req, h) => {
           // return h.response('Hello!').code(201);
          // const payload = req.payload;
          // cons name = payload.name;
            return 'Hello!';
        }
    });
*/
    routes.forEach(routes => server.route(routes));

    db.connect();
    await server.start();
    console.log('Server is listening on '+ server.info.uri);

}
process.on('unhandledRejection', err=> {
    console.log(err);
    process.exit(1);
});

process.on('SIGINT', async() =>{/*'async; is used since 'await is used inside,This is used when we use ctrl+c to kill the server*/
    console.log('Stopping Server..');
    await server.stop({timeout : 10000 });   /*how long to wait before it forces the server to quit*/
    db.end();
    console.log('Server Stopped..');
    process.exit(0);
});
start();