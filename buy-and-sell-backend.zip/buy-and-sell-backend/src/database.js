import mysql from 'mysql';

const connection  = mysql.createConnection({
    host : 'localhost',
    user : 'hapi-server',   
    password: 'Abcd*1234', /*we have to link this user, password to mysql workbench 
    in admin user and privileges, To get connection from the mysql server, 
    Then Add Entry in schema privileges as 'buy-and-sell' and add rights we need as 
    select,update, insert and delete*/
    database: 'buy-and-sell', /*schema name that we have create in mysql workbench*/
});

/* export an object from this file*/

export const db =  {
    
   connect: () => connection.connect(),/*sever will call this object 'connect' to connection with the database*/
   
   query: (queryString, escapedValues) =>/*wraps mysql's provided provided querying functinality*/
    new Promise((resolve, reject) =>{
            
            connection.query(queryString,escapedValues,(error, result, fields =>{
                if(error) reject(error);
                resolve({results, fields});
                console.log('connection'+ connection.query);
            }))
        }),
    end : () => connection.end(),
   
}
